
import React from 'react';

export default function Navbar() {
  return (
    <nav style={{padding:'12px', background:'#222', color:'white'}}>
      <h2>SecureVision AI</h2>
    </nav>
  );
}
