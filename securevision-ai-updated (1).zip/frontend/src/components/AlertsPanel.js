
import React from 'react';

export default function AlertsPanel({ alerts }) {
  return (
    <div style={{
      border:'1px solid #ccc',
      padding:'10px',
      width:'300px',
      height:'300px',
      overflow:'auto',
      background:'#f8f8f8'
    }}>
      <h4>Alerts</h4>
      {alerts.length === 0 && <p>No alerts yet.</p>}
      {alerts.map((a,i)=>(
        <div key={i} style={{padding:'5px', marginBottom:'5px', background:'white', borderRadius:'6px'}}>
          <b>{a.type}</b><br/>
          {a.time}
        </div>
      ))}
    </div>
  );
}
