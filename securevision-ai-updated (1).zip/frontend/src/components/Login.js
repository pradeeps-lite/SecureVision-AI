
import React, { useState } from 'react';

export default function Login({ setToken }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  async function submitLogin() {
    const res = await fetch('http://localhost:5000/api/auth/login', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({username, password})
    });
    const data = await res.json();
    if(data.token) setToken(data.token);
    else alert("Invalid Credentials");
  }

  return (
    <div style={{padding:'20px'}}>
      <h3>Login</h3>
      <input placeholder="Username" onChange={e=>setUsername(e.target.value)} />
      <br/><br/>
      <input type="password" placeholder="Password" onChange={e=>setPassword(e.target.value)} />
      <br/><br/>
      <button onClick={submitLogin}>Login</button>
    </div>
  );
}
