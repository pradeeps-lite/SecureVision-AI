
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Login from './components/Login';
import AlertsPanel from './components/AlertsPanel';
import './App.css';

function App() {
  const [token, setToken] = useState('');
  const [alerts, setAlerts] = useState([]);

  const streamUrl = 'http://localhost:5000/api/stream';

  // Fake alert generator for UI preview
  function addAlert(type) {
    setAlerts(prev => [...prev, {type, time: new Date().toLocaleTimeString()}]);
  }

  return (
    <div>
      <Navbar />

      {!token && <Login setToken={setToken} />}

      {token && (
        <div style={{display:'flex', padding:'20px', gap:'20px'}}>
          <div>
            <h3>Live Stream</h3>
            <img 
              alt="stream"
              src={streamUrl}
              style={{width:'700px', border:'2px solid #333'}}
            />
            <br/><br/>
            <button onClick={()=>addAlert("Unknown Face Detected")}>Simulate Alert</button>
            <button onClick={()=>addAlert("AI Face Detected")}>Simulate AI Alert</button>
          </div>

          <AlertsPanel alerts={alerts} />
        </div>
      )}
    </div>
  );
}

export default App;
