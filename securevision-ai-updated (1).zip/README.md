
# 🚀 SecureVision AI  
[![Python](https://img.shields.io/badge/Python-3.10-blue)]()  
[![Flask](https://img.shields.io/badge/Backend-Flask-green)]()  
[![React](https://img.shields.io/badge/Frontend-React-blue)]()  
[![OpenCV](https://img.shields.io/badge/Computer%20Vision-OpenCV-orange)]()  
[![YOLO](https://img.shields.io/badge/Object%20Detection-YOLOv8-red)]()  
[![Face Recognition](https://img.shields.io/badge/Face%20Recognition-dlib-purple)]()  

SecureVision AI is a **real-time AI-powered intelligent surveillance system** built for threat detection, face recognition, and AI-generated (deepfake) face identification.  
It includes a modern **React dashboard**, secure API authentication, video streaming, and a modular backend.

---

## 📸 Screenshots  
Create a folder called `/screenshots` and place real images after running the system.

```
/screenshots
   ├── dashboard.png
   ├── detection_sample.png
   ├── ai_face_detected.png
   └── face_recognition.png
```

Placeholder preview:

![Dashboard](https://via.placeholder.com/900x400?text=SecureVision+Dashboard+Preview)
![AI Detection](https://via.placeholder.com/900x400?text=Real-time+Detection+Sample)

---

## ⭐ Features  
- 🔍 Real-time object detection (YOLO)  
- 🙂 Face recognition using dlib encodings  
- 🤖 AI-generated (deepfake) face detection (LBP heuristic)  
- 🖥 Modern React dashboard with alerts panel  
- 🔐 Secure login using JWT  
- 📡 MJPEG streaming endpoint  
- 📁 Auto-learning system (register new faces on the fly)

---

## 📁 Updated Project Structure  
```
securevision-ai/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   ├── models/
│   ├── utils/
│   └── known_faces/
│        ├── sample1/
│        │     └── face.jpg
│        └── sample2/
│              └── face.jpg
├── frontend/
│   ├── src/
│   │    ├── App.js
│   │    ├── components/
│   │    │       ├── AlertsPanel.js
│   │    │       ├── Login.js
│   │    │       └── Navbar.js
│   │    └── App.css
├── README.md
└── docker-compose.yml
```

---

## 🧪 Try SecureVision AI  

Backend  
```bash
cd backend
pip install -r requirements.txt
python app.py
```

Frontend  
```bash
cd frontend
npm install
npm start
```

---

## 🛡 Tech Stack  
**Backend:** Flask, OpenCV, YOLOv8, dlib, JWT  
**Frontend:** React JS  
**Other:** Docker, CORS, MJPEG streaming, AI heuristics  

---

## 📌 Author  
**Pradeep Sathapathi**  
Cybersecurity | AI | Computer Vision | R&D  
LinkedIn: <your-link>  
GitHub: <your-link>

---
